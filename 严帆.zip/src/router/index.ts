import Vue from "vue";
import VueRouter from "vue-router";
import List from '../components/List/List.vue'
import ChineseMusic from '../components/SongMenu/ChineseMusic.vue'
import EuropeMusic from '../components/SongMenu/EuropeMusic.vue'
import JapanMusic from '../components/SongMenu/JapanMusic.vue'
import KoreanMusic from '../components/SongMenu/KoreanMusic.vue'
import yueyuMusic from '../components/SongMenu/yueyuMusic.vue'
import SongMain from '../components/SongMenu/SongMain.vue'
import SongMenu from '../components/SongMenu/SongMenu.vue'
import Radio from '../components/Radio/Radio.vue'

Vue.use(VueRouter);

const routes=[
  {
    path:'/List',component:List,//List这个组件的路径
    children:[
      {path:'/List/SongMenu',
      component:SongMenu, //歌单这个组件的路径
      children:[
        //歌单默认主页面 SongMain
          { path:'/list/SongMenu/SongMain',
            component:SongMain,
          },
         {
          //  华语歌单路由
          path:'/list/SongMenu/ChineseMusic',
          component:ChineseMusic,
         },
        //  欧美歌单路由
         {  path:'/list/SongMenu/EuropeMusic',
            component:EuropeMusic,
         },
        //  日本歌单路由
        {  path:'/list/SongMenu/JapanMusic',
        component:JapanMusic,
        },
        // 韩国歌单路由
        { path:'/list/SongMenu/KoreanMusic',
          component:KoreanMusic
        },
        // 粤语歌单路由
        { path:'/list/SongMenu/yueyuMusic',
        component:yueyuMusic
        },
          {
            //歌单默认主页面 SongMain
          path:'',redirect:'/list/SongMenu/SongMain'
           }
              ]
      },
      // 主播电台
      {path:'/List/Radio',
      component:Radio,
      },
    ]
  },
]
const router = new VueRouter({
  linkActiveClass :'is-active', 
  mode: "history",
  base: process.env.BASE_URL,
  routes
});

export default router;

