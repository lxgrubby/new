<!-- App.vue是必须要求要有的 -->
<template>
    <!--头部导航区域-->
    <div>
        <nav-header></nav-header>  <!--这就相当于一个标签，-->
        <!--核心区域:分左右两边-->
        <router-view></router-view>
    </div>
</template>

<script>
    // 需要使用组件就要导入组件
    import NavHeader from "./components/NavHeader.vue";
    export default {
        data() {
            return {
                
            }
        },
        components:{
            // 导入头部标签，注册他
            NavHeader
        }
    }
</script>

<style>
</style>
