<template>
    <div id='list'>
            <li class='list'>推荐</li> 
            <li class='list'>排行榜</li> 
            <router-link to="/List/SongMenu" tag='li' class='list' >
               <a>歌单</a>
            </router-link>
            <router-link to="/List/Radio" tag='li' class='list' >
               <a>主播电台</a>
            </router-link>
            <li class='list'>歌手</li>
            <li class='list'>新碟上架</li>
        <router-view></router-view>
    </div>
</template>
<style >
    .list{
        background-color:red;
        padding-top:1em
    }
    #list{
        margin-top:1em;
    }
</style>>