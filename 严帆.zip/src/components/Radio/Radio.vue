<template>
<div class="container-fluid mt-3">
    <!-- 行 -->
    <div class="container">
        <!-- 行 -->
      <div class="row">
        <div class="change col-lg-12 col-sm-12 offset-lg-4">
            <!-- 图片 -->
                <el-carousel :interval="3000" arrow="always" :autoplay='false'>
                    <el-carousel-item v-for="item in imagesbox" :key="item.id">
                        <img :src=" item.idView" class="image"/>
                    </el-carousel-item>
                </el-carousel>
            <!-- 图片 -->
        </div>
      </div>
        <!-- 行 -->
        <div class="row">
            <div class='col-lg-12 col-sm-12 offset-lg-4'>
                <!-- 左边列表部分 -->
                <div class='left col-lg-6'>
                    <!--开头 -->
                    <div class="la">
                        <h4 class="display-1">推荐节目</h4>
                    </div>
                    <!-- 热门 -->
                    <div class='hot'>
                    <a>更多></a>
                    </div>
                    <!-- 红线 -->
                    <div class='red'></div>
                    <!-- 列表 -->
                    <div>
                        <ul class='ul1'>
                            <li>
                                <div class="row">
                                    <div class='cntimg col-lg-1'>
                                        <img class='cntimg' src="http://p1.music.126.net/2NhOnoqcp19qXihgKHtYLA==/109951164841079856.jpg?param=40x40" alt="">
                                    </div>
                                    <div class='cntf col-lg-8'>
                                        <h5 class="cnth">EP02 吴青峰#被潜规则?宝宝心里苦但宝宝不说</h5>
                                        <p class="cntp">韦礼安跟你鸟鸟天 Season 01</p>
                                    </div>
                                    <div class='cntt col-lg-2'>
                                        <div class='cnttt'>音乐故事</div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class='cntimg col-lg-1'>
                                        <img class='cntimg' src="http://p1.music.126.net/ijk4PhKhU9P1l_g9K2M8gQ==/109951164882716635.jpg?param=40x40" alt="">
                                    </div>
                                    <div class='cntf col-lg-8'>
                                        <h5 class="cnth">解封以后，那些武汉人还好么</h5>
                                        <p class="cntp">故事FM</p>
                                    </div>
                                    <div class='cntt col-lg-2'>
                                        <div class='cnttt'>人文历史</div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class='cntimg col-lg-1'>
                                        <img class='cntimg' src="http://p1.music.126.net/ZO7DPoNAk4j41Bj7AnArpw==/109951164880803423.jpg?param=40x40" alt="">
                                    </div>
                                    <div class='cntf col-lg-8'>
                                        <h5 class="cnth">别在迷惘的时候问自己要什么</h5>
                                        <p class="cntp">雪栾电台</p>
                                    </div>
                                    <div class='cntt col-lg-2'>
                                        <div class='cnttt'>感情调频</div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class='cntimg col-lg-1'>
                                        <img class='cntimg' src="http://p1.music.126.net/FF06cC2gC0WR_HDwxAhjXw==/109951164233606520.jpg?param=40x40" alt="">
                                    </div>
                                    <div class='cntf col-lg-8'>
                                        <h5 class="cnth">感情里面，遇到控制型男人怎么办？</h5>
                                        <p class="cntp">成年人情感指南</p>
                                    </div>
                                    <div class='cntt col-lg-2'>
                                        <div class='cnttt'>脱口秀</div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class='cntimg col-lg-1'>
                                        <img class='cntimg' src="http://p1.music.126.net/w714XxgeXt-o9CtZbAIasA==/109951164867597697.jpg?param=40x40" alt="">
                                    </div>
                                    <div class='cntf col-lg-8'>
                                        <h5 class="cnth">ASW.MIX005:TCTS</h5>
                                        <p class="cntp">ASW不眠电台</p>
                                    </div>
                                    <div class='cntt col-lg-2'>
                                        <div class='cnttt'>3D|电子</div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class='cntimg col-lg-1'>
                                        <img class='cntimg' src="http://p1.music.126.net/sE2Uy6d6d3FqKVyWEff8IQ==/109951164867317915.jpg?param=40x40" alt="">
                                    </div>
                                    <div class='cntf col-lg-8'>
                                        <h5 class="cnth">SCG Collects.007|Aazar-AAA#3 MIXTAPE</h5>
                                        <p class="cntp">SCG Supports</p>
                                    </div>
                                    <div class='cntt col-lg-2'>
                                        <div class='cnttt'>3D|电子</div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class='cntimg col-lg-1'>
                                        <img class='cntimg' src="http://p1.music.126.net/HfMi8c4BymQ9dqDIkOmZ9Q==/3401888991483818.jpg?param=40x40" alt="">
                                    </div>
                                    <div class='cntf col-lg-8'>
                                        <h5 class="cnth">抗疫人物志--新冠时期的爱情</h5>
                                        <p class="cntp">晚安米兰</p>
                                    </div>
                                    <div class='cntt col-lg-2'>
                                        <div class='cnttt'>情感调频</div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class='cntimg col-lg-1'>
                                        <img class='cntimg' src="http://p1.music.126.net/YhxbSiQMewfDmav0JQKqIQ==/109951164876902181.jpg?param=40x40" alt="">
                                    </div>
                                    <div class='cntf col-lg-8'>
                                        <h5 class="cnth">JFF1|电音玩家的动森打开方式</h5>
                                        <p class="cntp">3D|电子</p>
                                    </div>
                                    <div class='cntt col-lg-2'>
                                        <div class='cnttt'>3D|电子</div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class='cntimg col-lg-1'>
                                        <img class='cntimg' src="http://p1.music.126.net/tG229yKW5xeX2LEstELnsQ==/109951164645840191.jpg?param=40x40" alt="">
                                    </div>
                                    <div class='cntf col-lg-8'>
                                        <h5 class="cnth">Vol.467[云村广播小站]你照亮过我，所以...</h5>
                                        <p class="cntp">晚安沐语</p>
                                    </div>
                                    <div class='cntt col-lg-2'>
                                        <div class='cnttt'>情感调频</div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class='cntimg col-lg-1'>
                                        <img class='cntimg' src="http://p1.music.126.net/syODhQDTgfPdbt_RHKRYzg==/109951164850756009.jpg?param=40x40" alt="">
                                    </div>
                                    <div class='cntf col-lg-8'>
                                        <h5 class="cnth">JFF1|新冠横行：俱乐部变粮仓，大咖艺人...</h5>
                                        <p class="cntp">[动刺电报]</p>
                                    </div>
                                    <div class='cntt col-lg-2'>
                                        <div class='cnttt'>3D|电子</div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <!-- 列表 -->
                </div>
                <!-- 右边列表部分 -->
                <div class='right col-lg-6'>
                    <!--开头 -->
                    <div class="la">
                        <h4 class="display-1">节目排行榜</h4>
                    </div>
                    <div class='hot'>
                        <a>更多></a>
                    </div>
                    <!-- 红线 -->
                    <div class='red'></div>
                    <!-- 列表 -->
                    <div>
                        <ul class='ul1'>
                            <li>
                                <div class="row">
                                    <div class='cntimg col-lg-1'>
                                        <img src='@/assets/img/jiemulist/jiemu1.png'>
                                    </div>
                                    <div class='cntimg col-lg-1'>
                                        <img class='cntimg' src="http://p2.music.126.net/3OiQGgsmQpl7_q9TaPWo5A==/3376600210271961.jpg?param=40x40" alt="">
                                    </div>
                                    <div class='cntf col-lg-8'>
                                        <h5 class="cnth">最后遇见他</h5>
                                        <p class="cntp">是你的垚</p>
                                    </div>
                                    <div class='cntt col-lg-2'>
                                        <div class='cnttt'>音乐故事</div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class='cntimg col-lg-1'>
                                        <img src='@/assets/img/jiemulist/jiemu2.png'>
                                    </div>
                                    <div class='cntimg col-lg-1'>
                                        <img class='cntimg' src="http://p2.music.126.net/JpGpHfy_DUAWeuIQHrjYbg==/1418370012865049.jpg?param=40x40" alt="">
                                    </div>
                                    <div class='cntf col-lg-8'>
                                        <h5 class="cnth">一辈子那么长要和温柔的人在一起</h5>
                                        <p class="cntp">蕊希电台</p>
                                    </div>
                                    <div class='cntt col-lg-2'>
                                        <div class='cnttt'>人文历史</div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class='cntimg col-lg-1'>
                                        <img src='@/assets/img/jiemulist/jiemu3.png'>
                                    </div>
                                    <div class='cntimg col-lg-1'>
                                        <img class='cntimg' src="http://p2.music.126.net/LMt_oPWWDjMn_rZ6DVNiKg==/109951164676302998.jpg?param=40x40" alt="">
                                    </div>
                                    <div class='cntf col-lg-8'>
                                        <h5 class="cnth">惊雷(抒情版)</h5>
                                        <p class="cntp">皮卡丘的多多</p>
                                    </div>
                                    <div class='cntt col-lg-2'>
                                        <div class='cnttt'>感情调频</div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class='cntimg col-lg-1'>
                                        <img src='@/assets/img/jiemulist/jiemu4.png'>
                                    </div>
                                    <div class='cntimg col-lg-1'>
                                        <img class='cntimg' src="http://p1.music.126.net/xaqLg4wr0dJ2lufH146M-Q==/109951163800082196.jpg?param=40x40" alt="">
                                    </div>
                                    <div class='cntf col-lg-8'>
                                        <h5 class="cnth">后来遇见他(原唱 胡66)</h5>
                                        <p class="cntp">不够的不够</p>
                                    </div>
                                    <div class='cntt col-lg-2'>
                                        <div class='cnttt'>脱口秀</div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class='cntimg col-lg-1'>
                                        <img src='@/assets/img/jiemulist/jiemu5.png'>
                                    </div>
                                    <div class='cntimg col-lg-1'>
                                        <img class='cntimg' src="http://p1.music.126.net/BqHM3hlDz3uZvCDs9ZlCPQ==/109951164082360408.jpg?param=40x40" alt="">
                                    </div>
                                    <div class='cntf col-lg-8'>
                                        <h5 class="cnth">与我无关 王巨星(cover：阿亢)</h5>
                                        <p class="cntp">王巨星的电台</p>
                                    </div>
                                    <div class='cntt col-lg-2'>
                                        <div class='cnttt'>3D|电子</div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class='cntimg col-lg-1'>
                                        <img src='@/assets/img/jiemulist/jiemu6.png'>
                                    </div>
                                    <div class='cntimg col-lg-1'>
                                        <img class='cntimg' src="http://p1.music.126.net/6XIvRONkCdl2OFD1YjrLlQ==/109951164811744214.jpg?param=40x40" alt="">
                                    </div>
                                    <div class='cntf col-lg-8'>
                                        <h5 class="cnth">夏天的风(cover：温岚)</h5>
                                        <p class="cntp">翻斗花园601</p>
                                    </div>
                                    <div class='cntt col-lg-2'>
                                        <div class='cnttt'>3D|电子</div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class='cntimg col-lg-1'>
                                        <img src='@/assets/img/jiemulist/jiemu7.png'>
                                    </div>
                                    <div class='cntimg col-lg-1'>
                                        <img class='cntimg' src="http://p1.music.126.net/Qp0GyMTt3pxmUV60iKULdA==/109951163464146231.jpg?param=40x40" alt="">
                                    </div>
                                    <div class='cntf col-lg-8'>
                                        <h5 class="cnth">MOM</h5>
                                        <p class="cntp">网瘾少女叽</p>
                                    </div>
                                    <div class='cntt col-lg-2'>
                                        <div class='cnttt'>情感调频</div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class='cntimg col-lg-1'>
                                        <img src='@/assets/img/jiemulist/jiemu8.png'>
                                    </div>
                                    <div class='cntimg col-lg-1'>
                                        <img class='cntimg' src="http://p1.music.126.net/oyNvshsLFc5tBRQY2A8XDA==/109951164833620934.jpg?param=40x40" alt="">
                                    </div>
                                    <div class='cntf col-lg-8'>
                                        <h5 class="cnth">落霜</h5>
                                        <p class="cntp">是二智啊</p>
                                    </div>
                                    <div class='cntt col-lg-2'>
                                        <div class='cnttt'>3D|电子</div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class='cntimg col-lg-1'>
                                        <img src='@/assets/img/jiemulist/jiemu9.png'>
                                    </div>
                                    <div class='cntimg col-lg-1'>
                                        <img class='cntimg' src="http://p2.music.126.net/orQBQdYIpODdDMXAoiNTYA==/109951164873906657.jpg?param=40x40" alt="">
                                    </div>
                                    <div class='cntf col-lg-8'>
                                        <h5 class="cnth">夏天的风(cover:温岚)</h5>
                                        <p class="cntp">坠</p>
                                    </div>
                                    <div class='cntt col-lg-2'>
                                        <div class='cnttt'>情感调频</div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class='cntimg col-lg-1'>
                                        <img src='@/assets/img/jiemulist/jiemu10.png'>
                                    </div>
                                    <div class='cntimg col-lg-1'>
                                        <img class='cntimg' src="http://p2.music.126.net/k3a9XciKJZkqlp7lzRc3DQ==/109951164723385492.jpg?param=40x40" alt="">
                                    </div>
                                    <div class='cntf col-lg-8'>
                                        <h5 class="cnth">快睡吧</h5>
                                        <p class="cntp">晚安集C</p>
                                    </div>
                                    <div class='cntt col-lg-2'>
                                        <div class='cnttt'>3D|电子</div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <!-- 列表 -->
                </div>
                <!-- 右边列表部分 -->
            </div>
        </div>
        <!-- 音乐故事电台 -->
        <div class='row'>
            <div class="change col-lg-12 col-sm-12 offset-lg-4">
                <div class="la">
                    <h3 class="display-1">音乐故事.电台</h3>
                </div>
                <!-- 更多 -->
                <div class='hot'>
                    <a>更多></a>
                </div>
                <!-- 红线 -->
                <div class='red'></div>
                <!-- 电台 -->
                <div class='radio col-lg-6'>
                    <div class='radimg col-lg-4'>
                        <img  src="@/assets/img/radio/radio1.png" alt="">
                    </div>
                    <div class='cntf col-lg-8'>
                        <h3 class="cnth">韦礼安跟你鸟鸟天 Season 01</h3>
                        <p class="cntp">韦礼安和音乐人的趣味访谈</p>
                        </div>
                </div>
                <div class='radio col-lg-6'>
                    <div class='radimg col-lg-4'>
                        <img  src="@/assets/img/radio/radio2.png" alt="">
                    </div>
                    <div class='cntf col-lg-8'>
                        <h3 class="cnth">木上先生的诗</h3>
                        <p class="cntp">通过声音穿过耳朵直抵你心</p>
                        </div>
                </div>
                <div class='radio col-lg-6'>
                    <div class='radimg col-lg-4'>
                        <img  src="@/assets/img/radio/radio3.png" alt="">
                    </div>
                    <div class='cntf col-lg-8'>
                        <h3 class="cnth">晓苏电台</h3>
                        <p class="cntp">没晚用音乐和你说晚安</p>
                        </div>
                </div>
                <div class='radio col-lg-6'>
                    <div class='radimg col-lg-4'>
                        <img  src="@/assets/img/radio/radio4.png" alt="">
                    </div>
                    <div class='cntf col-lg-8'>
                        <h3 class="cnth">糖蒜音乐故事</h3>
                        <p class="cntp">每个人喜欢的音乐都呆着故事</p>
                        </div>
                </div>
                
                <!-- 电台 -->
            </div>
        </div>
        <!-- 美文读物电台 -->
        <div class='row'>
            <div class="change col-lg-12 col-sm-12 offset-lg-4">
                <div class="la">
                    <h3 class="display-1">美文读物.电台</h3>
                </div>
                <!-- 更多 -->
                <div class='hot'>
                    <a>更多></a>
                </div>
                <!-- 红线 -->
                <div class='red'></div>
                <!-- 电台 -->
                <div class='radio col-lg-6'>
                    <div class='radimg col-lg-4'>
                        <img  src="@/assets/img/radio/radio5.png" alt="">
                    </div>
                    <div class='cntf col-lg-8'>
                        <h3 class="cnth">孤单小孩爱听故事</h3>
                        <p class="cntp">韦礼安和音乐人的趣味访谈</p>
                        </div>
                </div>
                <div class='radio col-lg-6'>
                    <div class='radimg col-lg-4'>
                        <img  src="@/assets/img/radio/radio6.png" alt="">
                    </div>
                    <div class='cntf col-lg-8'>
                        <h3 class="cnth">罗洋的秘制鸡汤</h3>
                        <p class="cntp">用实力为你烹制生活中的感动</p>
                        </div>
                </div>
                <div class='radio col-lg-6'>
                    <div class='radimg col-lg-4'>
                        <img  src="@/assets/img/radio/radio7.png" alt="">
                    </div>
                    <div class='cntf col-lg-8'>
                        <h3 class="cnth">原谅我眼里满是烟火</h3>
                        <p class="cntp">给你的耳朵讲故事</p>
                        </div>
                </div>
                <div class='radio col-lg-6'>
                    <div class='radimg col-lg-4'>
                        <img  src="@/assets/img/radio/radio8.png" alt="">
                    </div>
                    <div class='cntf col-lg-8'>
                        <h3 class="cnth">洞见官方博客</h3>
                        <p class="cntp">不是每一个观点都可以叫洞见</p>
                        </div>
                </div>
                <!-- 电台 -->
            </div>
        </div>
        <!-- 脱口秀电台 -->
        <div class='row'>
            <div class="change col-lg-12 col-sm-12 offset-lg-4">
                <div class="la">
                    <h3 class="display-1">脱口秀.电台</h3>
                </div>
                <!-- 更多 -->
                <div class='hot'>
                    <a>更多></a>
                </div>
                <!-- 红线 -->
                <div class='red'></div>
                <!-- 电台 -->
                <div class='radio col-lg-6'>
                    <div class='radimg col-lg-4'>
                        <img  src="@/assets/img/radio/radio9.png" alt="">
                    </div>
                    <div class='cntf col-lg-8'>
                        <h3 class="cnth">跑火车脱口秀</h3>
                        </div>
                </div>
                <div class='radio col-lg-6'>
                    <div class='radimg col-lg-4'>
                        <img  src="@/assets/img/radio/radio10.png" alt="">
                    </div>
                    <div class='cntf col-lg-8'>
                        <h3 class="cnth">Nice Try</h3>
                        <p class="cntp">这是一个每周更新的人声挑战节目</p>
                        </div>
                </div>
                <div class='radio col-lg-6'>
                    <div class='radimg col-lg-4'>
                        <img  src="@/assets/img/radio/radio11.png" alt="">
                    </div>
                    <div class='cntf col-lg-6'>
                        <h3 class="cnth">GQ Talk</h3>
                        <p class="cntp">一周一会的声音派对</p>
                        </div>
                    </div>
                <div class='radio col-lg-6'>
                    <div class='radimg col-lg-4'>
                        <img  src="@/assets/img/radio/radio12.png" alt="">
                    </div>
                    <div class='cntf col-lg-8'>
                        <h3 class="cnth">右弦电台</h3>
                        <p class="cntp">科幻奇幻影视，铁杆游戏玩家必听</p>
                        </div>
                </div>
                <!-- 电台 -->
            </div>
        </div>
        <!-- 情感调频电台 -->
        <div class='row'>
            <div class="change col-lg-12 col-sm-12 offset-lg-4">
                <div class="la">
                    <h3 class="display-1">情感调频.电台</h3>
                </div>
                <!-- 更多 -->
                <div class='hot'>
                    <a>更多></a>
                </div>
                <!-- 红线 -->
                <div class='red'></div>
                <!-- 电台 -->
                <div class='radio col-lg-6'>
                    <div class='radimg col-lg-4'>
                        <img  src="@/assets/img/radio/radio13.png" alt="">
                    </div>
                    <div class='cntf col-lg-8'>
                        <h3 class="cnth">丧气少女的微甜情话</h3>
                        <p class="cntp">写给未来自己的999封情书</p>
                        </div>
                </div>
                <div class='radio col-lg-6'>
                    <div class='radimg col-lg-4'>
                        <img  src="@/assets/img/radio/radio14.png" alt="">
                    </div>
                    <div class='cntf col-lg-8'>
                        <h3 class="cnth">仙女喜欢ZR</h3>
                        <p class="cntp">这是一个每周更新的人声挑战节目</p>
                        </div>
                </div>
                <div class='radio col-lg-6'>
                    <div class='radimg col-lg-4'>
                        <img  src="@/assets/img/radio/radio15.png" alt="">
                    </div>
                    <div class='cntf col-lg-6'>
                        <h3 class="cnth">哄睡觉</h3>
                        <p class="cntp">温柔干净的声音占领你的心</p>
                        </div>
                </div>
                <div class='radio col-lg-6'>
                    <div class='radimg col-lg-4'>
                        <img  src="@/assets/img/radio/radio16.png" alt="">
                    </div>
                    <div class='cntf col-lg-8'>
                        <h3 class="cnth">淡蓝彩虹电台</h3>
                        <p class="cntp">不一样的烟火，一样的绽放</p>
                        </div>
                </div>
                <!-- 电台 -->
            </div>
        </div>
        <!-- 页脚 -->
        <div class='foot'>
            <div class='row'>
            <div class="col-lg-6 col-sm-12 offset-lg-4">
                <p>
                    <a>服务条款|</a>
                    <a>隐私政策|</a>
                    <a>版权投诉指引|</a>
                    <a>意见反馈|</a>
                </p>
                <p>
                    <span>网易公司版权所有@1997-2020 杭州乐读科技有限公司运营：</span>
                    <a>浙网文[2018]3506-263号</a>
                </p>
                <p>
                    <span>违法和不良信息举报电话：0571-89853516 举报邮箱：</span>
                    <a>ncm599@163.com</a>
                </p>
                <p>
                    <span>粤B2-20090191-18</span>
                    <a>工业和信息化部备案管理系统网站</a>
                </p>
            </div>
            <div class="col-lg-6 col-sm-12 offset-lg-4">
                <img src='@/assets/img/foot/foot1.png'>
            </div>

            </div>
        </div>
        <!-- 页脚 -->
    </div>
</div>
</template>
<style>
    *{
        list-style:none;
    }
    .left{
        height:100%;
        display:inline;
    }
    .right{
        height:100%;
        display:inline;
    }
    .image{
    font-size: 18px;
    opacity: 0.75;
    line-height: 300px;
    margin: 0;
    width:100%
    }
    .el-carousel__item h3 {
    color: #475669;
    font-size: 18px;
    opacity: 0.75;
    line-height: 300px;
    margin: 0;
    }
    .el-carousel__item:nth-child(2n) {
    background-color: #d3dce6;
    }
  .el-carousel__item:nth-child(2n+1) {
    background-color: #d3dce6;
  }
  .cntf{
      display:inline;
  }
  .cntimg{
      display:inline;
  }
  h5{
      display:inline;
  }
  .cntt{
      height:50px
  }
  .cnttt{
      border:1px solid #000;
      margin-top:1em
  }
  .ul1{
      padding:0
  }
  .foot{
      margin-top:2em
  }
</style>
<script>
export default {
    data() {
        return {
            imagesbox:[{id:0,idView:require("../../assets/img/lunbo1.png")},
            {id:1,idView:require("../../assets/img/lunbo2.png")},
            ]
        }
    },
}
</script>