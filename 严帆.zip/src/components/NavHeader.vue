<template>
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">{{projectName}}</a>
        </div>
        <router-link to="/List" tag='li' >
               <a class="navbar-brand" href="#">发现音乐</a>
            </router-link>
        <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-right">
            <li><a href="#">查看</a></li>
            <li><a href="#">设置</a></li>
            <li><a href="#">登录</a></li>
            </ul>
            <form class="navbar-form navbar-right">
            <input type="text" class="form-control" placeholder="音乐/视频">
            </form>
        </div>
        </div>
    </nav>
</template>

<script>
    export default {
        data() {
            return {
                projectName:'网易云音乐' 
            }
        }
    }
</script>
<style >
    .navbar{
        padding-bottom:2em;
    }
</style>
