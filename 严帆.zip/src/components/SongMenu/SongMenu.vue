<template>
<div class="container-fluid mt-3">
    <!-- 行 -->
    <div class="container">
      <div class="row">
        <div class="change col-lg-12 col-sm-12 offset-lg-4">
                <!-- 全部 -->
                    <div class="la">
                        <h4 class="display-1">全部</h4>
                    </div>
          <!-- 下拉框 -->
                    <div class="dropdown">
                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        选择分类
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                                <router-link to="/list/SongMenu/ChineseMusic" tag='li' >
                                    <a class="navbar-brand" href="#">华语</a>
                                </router-link>
                                <router-link to="/list/SongMenu/EuropeMusic" tag='li' >
                                    <a class="navbar-brand" href="#">欧美</a>
                                </router-link>
                                <router-link to="/list/SongMenu/JapanMusic" tag='li' >
                                    <a class="navbar-brand" href="#">日语</a>
                                </router-link>
                                <router-link to="/list/SongMenu/KoreanMusic" tag='li' >
                                    <a class="navbar-brand" href="#">韩语</a>
                                </router-link>
                                <router-link to="/list/SongMenu/yueyuMusic" tag='li' >
                                    <a class="navbar-brand" href="#">粤语</a>
                                </router-link>
                        </div>
                    </div>
                    <!-- 下拉框 -->
                    <!-- 热门 -->
                    <div class='hot'>
                    <button id='hot' type="button" class="btn btn-danger">热门</button>
                    </div>
                    <!-- 红线 -->
                    <div class='red'></div>
        </div>
      </div>
      <router-view></router-view>
        <!-- 分页栏 -->
        <el-row>
            <el-col :span="8" :offset='8'>
                <el-pagination
                    background
                    layout="prev, pager, next"
                    :pager-count="7"
                    :total="1000">
                </el-pagination>
            </el-col>
        </el-row>
        <!-- 页脚 -->
        <div class='foot'>
            <div class='row'>
            <div class="col-lg-6 col-sm-12 offset-lg-4">
                <p>
                    <a>服务条款|</a>
                    <a>隐私政策|</a>
                    <a>版权投诉指引|</a>
                    <a>意见反馈|</a>
                </p>
                <p>
                    <span>网易公司版权所有@1997-2020 杭州乐读科技有限公司运营：</span>
                    <a>浙网文[2018]3506-263号</a>
                </p>
                <p>
                    <span>违法和不良信息举报电话：0571-89853516 举报邮箱：</span>
                    <a>ncm599@163.com</a>
                </p>
                <p>
                    <span>粤B2-20090191-18</span>
                    <a>工业和信息化部备案管理系统网站</a>
                </p>
            </div>
            <div class="col-lg-6 col-sm-12 offset-lg-4">
                <img src='@/assets/img/foot/foot1.png'>
            </div>

            </div>
        </div>
        <!-- 页脚 -->
    </div>

  </div>
</template>
<style >
    .dropdown{
       display:inline
    }
    .la{
        display:inline;
    }
    .display-1{
        display:inline
    }
    .hot{
        display:inline;
        float:right
    }
    #hot{
        display:inline;
    }
    .card{
        padding:0;
        margin:1.5em
    }
    .red{
        width:100%;
        height:2px;
        background-color:red;
        margin-top:1em;
        margin-bottom:1em
    }
    .change{
        margin-top:1em
    }
</style>
