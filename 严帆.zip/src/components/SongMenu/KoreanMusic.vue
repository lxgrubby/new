<template>
    <div class="container">
        <div class="row">
            <div class='col-lg-12 col-sm-12 offset-lg-4'>
                <!-- 卡片1 -->
                <div class="card col-lg-2 col-sm-12 my-2 " style="width: 18rem;">
                    <img src="@/assets/img/Korean/kor1.png" class="card-img-top" >
                        <div class="card-body">
                        <h5 class="card-title">如沐春风|一起感受</h5>
                        <p class="card-text">by 飞行棋的猫mor</p>
                        </div>
                </div>
                <!-- 卡片2 -->
                <div class="card col-lg-2 col-sm-12 my-2 " style="width: 18rem;">
                    <img src="@/assets/img/Korean/kor2.png" class="card-img-top" >
                        <div class="card-body">
                        <h5 class="card-title">人间四月只想听见烂漫</h5>
                        <p class="card-text">by华纳音乐</p>
                        </div>
                </div>
                <!-- 卡片3 -->
                <div class="card col-lg-2 col-sm-12 my-2" style="width: 18rem;">
                    <img src="@/assets/img/Korean/kor3.png" class="card-img-top" >
                        <div class="card-body">
                        <h5 class="card-title">【仙女气电】沉醉于...</h5>
                        <p class="card-text">by一生向海</p>
                        </div>
                </div>
                <!-- 卡片4 -->
                <div class="card col-lg-2 col-sm-12 my-2" style="width: 18rem;">
                    <img src="@/assets/img/Korean/kor4.png" class="card-img-top" >
                        <div class="card-body">
                        <h5 class="card-title">【一周欧美上心】少年...</h5>
                        <p class="card-text">by 网易云音乐</p>
                        </div>
                </div>
                <!-- 卡片5 -->
                <div class="card col-lg-2 col-sm-12 my-2" style="width: 18rem;">
                    <img src="@/assets/img/Korean/kor5.png" class="card-img-top" >
                        <div class="card-body">
                        <h5 class="card-title">【一周原创发现】Yee...</h5>
                        <p class="card-text">by原创君</p>
                        </div>
                </div>
                <!-- 卡片6 -->
                <div class="card col-lg-2 col-sm-12 my-2" style="width: 18rem;">
                    <img src="@/assets/img/Korean/kor6.png" class="card-img-top" >
                        <div class="card-body">
                        <h5 class="card-title">私人雷达|根据听歌...</h5>
                        <p class="card-text">by网易云音乐智能推荐</p>
                        </div>
                </div>
                <!-- 卡片7 -->
                <div class="card col-lg-2 col-sm-12 my-2" style="width: 18rem;">
                    <img src="@/assets/img/Korean/kor7.png" class="card-img-top" >
                        <div class="card-body">
                        <h5 class="card-title">千里狗/陈阳/王巨星...</h5>
                        <p class="card-text">by Dexter_RV</p>
                        </div>
                </div>
                <!-- 卡片8 -->
                <div class="card col-lg-2 col-sm-12 my-2" style="width: 18rem;">
                    <img src="@/assets/img/Korean/kor8.png" class="card-img-top" >
                        <div class="card-body">
                        <h5 class="card-title">【欧美私人订制】最懂...</h5>
                        <p class="card-text">by网易云音乐</p>
                        </div>
                </div>
                <!-- 卡片9 -->
                <div class="card col-lg-2 col-sm-12 my-2" style="width: 18rem;">
                    <img src="@/assets/img/Korean/kor9.png" class="card-img-top" >
                        <div class="card-body">
                        <h5 class="card-title">熬夜写作业必备醒脑...</h5>
                        <p class="card-text">by喜爱吃糖的小小高</p>
                        </div>
                </div>
                <!-- 卡片10 -->
                <div class="card col-lg-2 col-sm-12 my-2" style="width: 18rem;">
                    <img src="@/assets/img/Korean/kor10.png" class="card-img-top" >
                        <div class="card-body">
                        <h5 class="card-title">网易云评论最多的纯...</h5>
                        <p class="card-text">by 长沙de郭德纲</p>
                        </div>
                </div>
                <!-- 卡片15 -->
            </div>
        </div>
    </div>
</template>