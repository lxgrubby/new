// 导入vue，导入App.vue,导入路由
import Vue from "vue";
import axios from 'axios' //导入axios
import App from "./App.vue";
import router from "./router";
// 导入VUEX的对象
import store from "./store";
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';

Vue.use(ElementUI);
Vue.config.productionTip = false;

new Vue({
  router,
  store,
  render: h => h(App)  //react中的语法
}).$mount("#app");
